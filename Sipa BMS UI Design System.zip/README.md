# Sipa BMS UI — Design System

A design-system package extracted from **`@ouestfrance/sipa-bms-ui`**, the Vue 3 component library used by the BMS (Business Management Systems) team at Ouest-France / Groupe Sipa to build internal back-offices and admin tooling.

> _"Librairie de composants et plugins VueJS pour les projets de l'équipe BMS du groupe Sipa."_ — upstream README

---

## Context & product

**Sipa BMS UI** is a shared component toolkit, not a product itself. It powers the internal admin / back-office interfaces used across editorial, commercial and operational teams at Ouest-France. The library:

- Is published as **`@ouestfrance/sipa-bms-ui`** (previously `sipa-bms-ui` before the v8 org rename) on npm.
- Ships ~70+ `Bms*` Vue components covering buttons, forms, tables, navigation, feedback, and layout primitives.
- Ships a companion set of lower-level `Ui*` primitives (e.g. `UiButton`, `UiMenuItem`, `UiTooltip`) that the `Bms*` components compose.
- Bundles six Vue plugins: `field`, `notifications`, `confirm`, `router-history`, `feature-flipping`, `runtime-env`, plus a `keycloak-auth-adapter` for SSO.
- Requires **Vue 3** (not Vue 2-compatible) and `vue-router` as the app router.
- Uses **Roboto** as its default typeface, a soft-blue primary (`#69a9e1`) on a near-white surface, and supports a dark mode via `light-dark()` CSS variables.

Everything in this design system is meant to let a non-codebase consumer (agents, designers, anyone prototyping) build **visually-correct mocks, slides, and throwaway prototypes** that look like real BMS admin tools.

## Sources

Everything in this pack was extracted from a **local copy** of the BMS component library repository attached as `platform-library-vuejs-bms/`. Key files read:

| File | What it gave us |
|---|---|
| `src/assets/scss/global-variables.scss` | The entire `--bms-*` CSS variable system — colors, radii, shadows, z-index, disabled states. |
| `src/assets/scss/_conf.scss` | Base typography, semantic heading sizes, body/link defaults, fade transitions, breakpoints. |
| `src/assets/scss/app.scss` | Roboto font import, application of the root `styles` + `global-variables` mixins. |
| `src/components/button/UiButtonLink.vue` | The full color-mode matrix (`fill` / `outline` / `ghost` / `is-icon`) × (`default` / `warning` / `danger` / `success`). |
| `src/components/button/BmsButton.vue` | Button public API (`type: primary/secondary/tertiary`, `mode: StatusType`). |
| `src/components/layout/BmsCard.vue` | "Glass" card treatment with blur, blob hover, and status-colored variants. |
| `src/components/layout/BmsModal.vue` | Modal sizing, header border thickness by status, loader overlay. |
| `src/components/layout/BmsHeader.vue` | Sticky app header (padding, 1px border-bottom). |
| `src/components/feedback/BmsAlert.vue`, `BmsBadge.vue`, `BmsCaption.vue`, `BmsLoader.vue`, `BmsTooltip.vue` | Feedback language — alerts, badges, inline validation, spinners. |
| `src/components/form/BmsInputText.vue`, `RawInputText.vue`, `BmsChip.vue`, `BmsTag.vue` | Form field chrome, chip/tag palette. |
| `src/components/navigation/BmsMenu.vue`, `BmsMenuNav.vue`, `UiMenuItem.vue` | Slide-out left nav, active state with left `bar`, hover color shift. |
| `src/components/table/BmsTable.vue` | Empty-state copy, French UI strings, table-filter UX. |
| `src/showroom/*` | Canonical demo pages — `server-table.vue`, `forms.vue`, `stepper.vue` — the intended look of a BMS back-office view. |
| `public/logo.png`, `public/favicon.ico` | Brand marks (copied to `assets/`). |
| `src/assets/empty.svg` | Empty-state illustration. |

Upstream repository: `https://gitlab.ouest-france.fr/sipa-ouest-france/platform/platform-library-vuejs-bms.git`
Upstream README (French): `platform-library-vuejs-bms/README.md`

---

## CONTENT FUNDAMENTALS

BMS UI ships French-first copy. If you're building in this system, **write in French unless the target app overrides it**.

### Voice & tone
- **Professional, understated, informational.** This is an internal admin toolkit — not a marketing site. No exclamation marks beyond gentle emphasis, no emoji in product copy, no slang.
- **Vouvoiement (formal "you") is implied, never "tu".** Direct address is rare: the library leans on impersonal framings (`Aucune donnée`, `Votre recherche n'a retourné aucun résultat`) rather than "You have no data".
- **Action-oriented verbs for buttons**, infinitive form: `Annuler`, `Valider`, `Supprimer`, `Enregistrer`, `Confirmer`.
- **Descriptive, non-dramatic error language.** Validation errors state the constraint, not blame: `Longueur inférieur au minimum autorisé (min:3)`, `La valeur ne correspond pas au motif attendu`, `Attention, vous avez atteint la limite de 200 caractères.`

### Casing
- **Sentence case everywhere.** Buttons, headers, table column labels. Never Title Case, never ALL CAPS in content.
- One notable exception in the codebase: the left-nav **parent-level labels are `text-transform: uppercase` via CSS** (`BmsMenuNav.vue`). Source data is still sentence case — the visual uppercase is a styling choice, not a copy choice.

### Specific examples (pulled verbatim)
| Context | Copy |
|---|---|
| Empty table (no data) | `Aucune donnée` / `Il semblerait qu'il n'y ait rien ici...` |
| Empty table (no search match) | `Aucun résultat` / `Votre recherche n'a retourné aucun résultat.` |
| Modal default buttons | `Ok` / `Annuler` |
| Menu footer | `Made with ♥ by BMS` |
| Menu aria-labels | `Ouvrir le menu` / `Fermer le menu` |
| Max-length warning | `Attention, vous avez atteint la limite de {N} caractères.` |

### Emoji, icons-as-text, unicode
- **No emoji in product UI.** The only emoji in the entire repo is `♥` (U+2665) in the menu footer "Made with ♥ by BMS" — a signature touch, not a pattern to copy into feature work.
- **No unicode pictographs** (checkmarks, stars, etc.) used as icons. All iconography goes through `lucide-vue-next`.

---

## VISUAL FOUNDATIONS

### Typography
- **Roboto** 400/500/700, loaded from Google Fonts in `app.scss`. Fallback: Arial, Helvetica, sans-serif.
- Root sizing trick: `html { font-size: 62.5% }` so `1rem = 10px`. Body is `1.6rem = 16px`.
- Headings come from `_conf.scss`:
  - `h1` — 40/40, weight 400 (light for a display heading — distinctive to BMS)
  - `h2` — 28/24, weight 400
  - `h3` — 20/20, weight 600 (the only heavy heading)
  - Captions / `.information` — 14px, color `--bms-grey-75`

### Color system
A **six-ramp system, 140/100/75/50/25/10** — per-ramp the `100` is the canonical color, `140` is the hover/darker variant, `10` is the wash/tint used as backgrounds for soft alerts and chips.

| Ramp | 100 (canonical) | Role |
|---|---|---|
| grey | `#526476` | Neutral text, disabled borders |
| main | `#69a9e1` | **Primary brand blue** — buttons, links, focused state |
| main-analog | `#696ce0` | Accent indigo, used sparingly (chip `.purple`) |
| green | `#57b47d` | Success |
| orange | `#f08e13` | Warning |
| red | `#dc474c` | Danger |

Surfaces: `--bms-white` (`#fcfcfc` light / `#222831` dark) sits on `--bms-background-color` (`#f8fafd` / `#151d28`). Dark mode is real and driven by the `light-dark()` function — flip `--bms-color-scheme: dark` at the root and everything re-paints.

### Spacing
There is no explicit spacing scale file. Components use a pragmatic em-based rhythm: `0.25em` / `0.5em` / `1em` / `2em` for internal padding, and hard pixel values for form chrome (`padding: 16px`, `gap: 16px`, `gap: 8px`).

### Backgrounds
- **Flat, warm-neutral surfaces.** No hero gradients, no bluish-purple gradients, no hand-drawn illustrations. The app background is a very faint cool-white (`#f8fafd`); cards sit on `--bms-white`.
- **The "glass" card** (`BmsCard.vue`) is the one special treatment: a `backdrop-filter: blur(40px)` over a 50%-opacity fill, with an animated soft blur "blob" that follows the cursor. This is the closest thing BMS has to a signature visual.
- No repeating patterns, no textures, no full-bleed photography in the library.

### Borders & radii
- `--bms-border-radius: 4px` (buttons, inputs, chips)
- `--bms-border-radius-large: 8px` (cards, modals, alerts, sections)
- `--bms-border-radius-xlarge: 16px` (tags only — the pill tag is the one "soft" shape)
- All borders are 1px solid `--bms-border-color` (= `--bms-grey-10` light / `--bms-grey-100` dark) — or the semantic color when in an alert/error state.

### Shadows
Two elevation tokens only:
- `--bms-box-shadow` — moderate: tooltips, popovers
- `--bms-box-shadow-elevated` — modals, floating windows; includes a 1px inner ring in dark mode for contrast.
No inset shadows. Focus state uses a **4px glow**, not a shadow: `box-shadow: 0 0 4px 4px var(--bms-main-25)` on focused inputs.

### Animation
- **Fades and slide-lefts, all short and linear-ish.** Canonical `--transition-duration: 0.2s`.
- Named Vue transitions in `_conf.scss`: `fade` (opacity), `slide-left-fade` (`translate3d(-10%, 0, 0)` + opacity), `table-fade` (opacity + max-height).
- Menu expand/collapse: `max-height` 0→500px with `0.7s ease` in, `0.25s linear` out.
- No bounces, no spring physics, no scale-on-hover except buttons' implicit `transform 0.1s ease-in-out`.

### Interactive states
- **Buttons.** Hover = `140` (darker) fill + border; outline/ghost also shift to the `140` text color. Disabled = grey-50 everywhere, `pointer-events: none`.
- **Inputs.** Hover thickens border to `--bms-grey-100`. Focus adds the 4px main-25 glow. Error = red-100 border + red-25 background fill.
- **Menu items.** Active = 4px vertical `bar` in main-100 on the left edge + main-100 text. Hover = bar + text shift to main-75.
- **Links.** Default = main-100, underline on hover.
- **Press state** is not distinguished from hover — the library relies on the `:active` pseudo using the same rules.

### Transparency & blur
Used exactly twice:
- **Card glass** (`backdrop-filter: blur(40px)` + 50% white fill).
- **Loader blob** (`filter: blur(10px)` on a colored circle).
Everywhere else, surfaces are opaque.

### Cards
Cards have a 1px grey-10 border, 8px radius, no drop shadow by default. A status-variant (`information`, `success`, `warning`, `danger`) paints the inside surface the semantic color and flips text to white. An optional `action` slot adds a full-width bottom bar with its own border-top and rounds only the top corners of the body.

### Layout rules
- **Sticky header**: 1px bottom border, `--bms-white` background, `z-index: 3`, `0.8rem 1rem` padding. No blur/transparency — it's a hard hairline.
- **Menu** slides from the left, takes `24rem + 3rem` margin, rounded 0.5rem, with a 1.5rem outer gutter so you see the page behind it.
- **Modals** are centered, min-width `32em`, max-width `80vw`. The header border-bottom thickness encodes status: 1px for default, 4px for success / warning / danger.

### Imagery "vibe"
The library ships almost no imagery: one logo (PNG, red on blue), one favicon, one `empty.svg` (outline style, stroke-only). If you need to add photography, keep it cool-neutral, low-saturation, no grain — it should not fight the soft-blue primary.

---

## ICONOGRAPHY

**Sipa BMS UI uses `lucide-vue-next` exclusively.** Every icon in the source is a Lucide icon imported by name:

```ts
import { AlertCircle, AlertTriangle, Info, X, Menu, ChevronDown, ChevronUp,
         Settings, CheckCircle, AlertOctagon, Trash } from 'lucide-vue-next';
```

Guidance for anyone rebuilding with this design system:

- **Use Lucide icons, 1.5px stroke, the default 24×24 viewBox.** In HTML mocks, load from CDN: `https://unpkg.com/lucide@latest` — the icon names match 1:1.
- **Render at 20px inside alerts/modals, 16–20px inside buttons, 14–16px inside tags and chips.** In code the library sets `svg { width: 1em; height: 1em }` and sizes by parent font-size — easy to replicate.
- **Color comes from the parent's text color** (via `currentColor`). Icons never carry their own fill; they recolor with the semantic state.
- **No emoji. No unicode pictographs.** (Exception: the `♥` easter egg in the menu footer.)
- **No custom icon font.** There are three `Animated*Icon.vue` files (`AnimatedHomeIcon`, `AnimatedActivityIcon`, `AnimatedCircleHelpIcon`) — bespoke Vue components for rare animated use cases; treat as out of scope for mocks.

The library's own logo and favicon have been copied into `assets/` (`logo.png`, `favicon.ico`). The sole illustration is `assets/empty.svg`.

> **Substitution note:** I did **not** copy a local Lucide icon set into `assets/` because the library imports them on demand from npm — the canonical delivery channel for mocks is the CDN. If you need Lucide offline, add `https://unpkg.com/lucide@latest/dist/umd/lucide.js` to the project and load `lucide.createIcons()`.

> **Font substitution note:** `colors_and_type.css` imports Roboto from Google Fonts (same as `app.scss` does at runtime). No local `.ttf` / `.woff2` files exist in the upstream repo — this is an intentional Google-Fonts-CDN pattern. If you need truly offline Roboto, download the Google Fonts bundle into `fonts/` and swap the `@import url(...)` line in `colors_and_type.css` for local `@font-face` rules. **Flag**: please confirm this CDN dependency is acceptable for your use case.

---

## Index (manifest of this design system)

| Path | What |
|---|---|
| `README.md` | This file. |
| `SKILL.md` | Agent Skill manifest — lets you download this folder and use it inside Claude Code. |
| `colors_and_type.css` | All `--bms-*` tokens, the 62.5% root trick, heading sizes, Roboto import. Drop into any HTML page. |
| `assets/logo.png` | BMS product logo (from `public/logo.png`). |
| `assets/favicon.ico` | BMS favicon. |
| `assets/empty.svg` | The one illustration — used in empty states by `BmsEmptyScreen`. |
| `preview/*.html` | Design-system review cards (palettes, type, components) — surfaced in the **Design System** tab. |
| `ui_kits/back-office/` | The one UI kit: a working click-thru of a BMS back-office view (sidebar, header, server table, filters, modal). |

There are no slide templates in this package — the source is a component library, not a deck kit.

---

## Caveats

- **Roboto is loaded from Google Fonts CDN**, mirroring the upstream library. No local `.ttf` files.
- **Lucide icons are referenced, not bundled** — the library does the same. For a fully-offline mock, self-host Lucide.
- **French-first copy.** Some strings are hardcoded French in the source (`Aucune donnée`, `Annuler`). I've preserved that in the UI kit.
- **Dark mode** is supported in tokens but the UI kit demo is light-mode by default. Flip `--bms-color-scheme: dark` on `:root` to test.
