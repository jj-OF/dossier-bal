---
name: sipa-bms-ui
description: Design system extracted from @ouestfrance/sipa-bms-ui — the Vue 3 component library used by the BMS team at Ouest-France / Groupe Sipa for internal back-office and admin UIs. Use when mocking Sipa BMS admin tools, editorial consoles, or any internal Ouest-France tooling that should match the BMS look and feel. French-first copy, soft-blue primary, Roboto, Lucide icons.
---

# Sipa BMS UI — design system

This skill bundles the tokens, typography, and visual language of Ouest-France's internal BMS component library so you can produce faithful mocks and prototypes without pulling the npm package.

## When to use

- Mocking internal admin screens for Ouest-France / Groupe Sipa (editorial CMS, planning tools, newsroom dashboards).
- Anything that should look like it was built with `<BmsButton>`, `<BmsTable>`, `<BmsModal>` etc.
- French back-office UIs with a soft-blue primary, Roboto, and status-coded chips / alerts.

**Not** for public-facing Ouest-France websites — those use a different brand system. This is the internal tooling layer only.

## How to use

1. **Read `README.md` first.** It contains the full content, visual, and iconography foundations, plus the sourcing notes. Do not skip — BMS has specific French-first copy rules and a distinct soft-blue palette that's easy to get wrong.
2. **Link `colors_and_type.css`** from any HTML you build. It sets up `--bms-*` tokens, loads Roboto from Google Fonts, and applies the `html { font-size: 62.5% }` root trick. All component styling downstream uses those variables.
3. **Look at `ui_kits/back-office/Gestion Éditoriale.html`** before designing a new screen — it's the canonical example of the layout (sticky header, left nav with active bar, soft-blue primary, status chips, modal, toast). Copy its shell patterns.
4. **Preview cards in `preview/`** show every token in isolation — palettes, type, radii, shadows, buttons, inputs, alerts, badges, chips, tags, cards, table rows, menu items, loader, icons. Use them to double-check color/state mappings.
5. **Icons: use Lucide** at 16–20px via CDN (`https://unpkg.com/lucide@latest`). The library imports from `lucide-vue-next` — same icon names. Never use emoji (except the `♥` in the menu footer, which is an intentional easter egg).

## Key constraints

- **Copy is French** by default. Use vouvoiement, sentence case everywhere (CSS uppercases nav parents visually — source is still sentence case). Buttons take infinitive verbs: `Annuler`, `Valider`, `Supprimer`.
- **Soft blue `#69a9e1` is primary** — not a saturated blue. Don't substitute.
- **Status encoding**: green = success, orange = warning, red = danger, grey = informational / neutral, indigo (`main-analog`) = used sparingly for accent chips.
- **Shadows are rare** — 1px grey-10 borders do most of the elevation work. Focus state uses a 4px main-25 glow, not a shadow.
- **No gradients, no hero imagery, no drawn illustrations** except the single `assets/empty.svg`. BMS is a functional admin aesthetic.

## Files

- `README.md` — full spec (content fundamentals, visual foundations, iconography, sourcing, caveats).
- `colors_and_type.css` — drop-in stylesheet with all `--bms-*` tokens and Roboto.
- `assets/logo.png`, `assets/favicon.ico`, `assets/empty.svg` — brand marks + the one illustration.
- `preview/*.html` — per-token review cards.
- `ui_kits/back-office/Gestion Éditoriale.html` — working click-through of a BMS back-office (sidebar, header, server table, filters, modal, toast).
